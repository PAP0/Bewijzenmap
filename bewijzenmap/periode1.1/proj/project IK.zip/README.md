# Padding en marge

download materiaal bij [opdracht padding en marge](http://blanken5.home.xs4all.nl/opdrachtPaddMarg.html "opdracht padding en marge").

### een mogelijke uitwerking
![afbeelding opdracht padding en marge](http://blanken5.home.xs4all.nl/afb/opdrPaddMarg/uitwerkingPadding.png)

### De bonusopdracht:
![afbeelding bonus padding en marge](http://blanken5.home.xs4all.nl/afb/opdrPaddMarg/bonusPadding.png)

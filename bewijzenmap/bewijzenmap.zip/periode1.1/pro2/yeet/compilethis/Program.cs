﻿using System;

namespace compilethis
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("Hello World my name is Patryk");
        }
    }
}

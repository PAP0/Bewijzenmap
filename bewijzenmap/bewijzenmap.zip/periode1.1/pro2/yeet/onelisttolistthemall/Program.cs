﻿using System;

namespace array
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] array1 = {"Pavlov VR","Minecraft VR","Onward","Beat Saber","The Forest","Arizona Sunshine","Superhot VR","Rick and Morty","Lone Echo","Vader Immortal"};

            Console.Clear();

            Console.WriteLine("10 VR Games");
            Console.WriteLine("");
            Console.WriteLine(array1[0]);
            Console.WriteLine(array1[1]);
            Console.WriteLine(array1[2]);
            Console.WriteLine(array1[3]);
            Console.WriteLine(array1[4]);
            Console.WriteLine(array1[5]);
            Console.WriteLine(array1[6]);
            Console.WriteLine(array1[7]);
            Console.WriteLine(array1[8]);
            Console.WriteLine(array1[9]);

        }
    }
}

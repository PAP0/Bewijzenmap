#Oefenpagina padding/margin
###Met een mogelijkheid om ook met box-sizing te werken.
Dit document bestaat uit 2 secties. Zehebben flinke overeenkomsten.
De tweede sectie heeft echter ook een aparte class. Als je daarin aanpassingen maakt kun je vervolgens kijken welke verschillen dat oplevert.

Speel dus met de css van .variant van deze pagina.
Bekijk de gevolgen door hem met de eerste sectie te vergelijken.
